package com.example.consuldemo

import org.junit.jupiter.api.Test
import org.springframework.boot.test.context.SpringBootTest

@SpringBootTest
class ConsulDemoApplicationTests {

	@Test
	void contextLoads() {
	}

}
